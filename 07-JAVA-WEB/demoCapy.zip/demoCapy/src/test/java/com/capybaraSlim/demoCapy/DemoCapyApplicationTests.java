package com.capybaraSlim.demoCapy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoCapyApplicationTests {

	@Test
	void contextLoads() {
	}

}
